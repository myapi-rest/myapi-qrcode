# Endpoints — QR Code API

Base URL: `https://api.myapi.rest`

---

## POST /api/qrcode/generate

Generate a QR code.

### Request Body

| Field             | Type    | Required | Description |
|-------------------|---------|----------|-------------|
| data              | string  | Yes      | Content encoded into the QR code. |
| output_format     | string  | Yes      | PNG, JPG, or SVG. |
| pixels_per_module | number  | No       | Module resolution. |
| margin            | number  | No       | Margin (quiet zone). |
| ecc_level         | string  | No       | Error correction level. |
| dark_color_hex    | string  | No       | Foreground color. |
| light_color_hex   | string  | No       | Background color. |
| draw_quiet_zones  | bool    | No       | Include quiet zones. |
| image_base64      | string  | No       | Optional embedding image. |
| logo_size_percent | number  | No       | Logo scaling percentage. |

### Success Response

```json
{
  "id": 5,
  "qrcode": "<BASE_64_DATA>"
}
```

### Error Response Example

```json
{
  "type": "https://tools.ietf.org/html/rfc9110#section-15",
  "title": "Invalid request",
  "status": 400,
  "detail": "data field is required",
  "instance": "/api/qrcode/generate"
}
```
