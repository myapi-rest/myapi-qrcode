# Errors — QR Code API

Errors follow the standardized myapi.rest format.

## Example Error

```json
{
  "type": "https://tools.ietf.org/html/rfc9110#section-15",
  "title": "Invalid request",
  "status": 400,
  "detail": "data field is required",
  "instance": "/api/qrcode/generate"
}
```

## Common Codes

| Status | Meaning |
|--------|---------|
| 400 | Invalid request |
| 401 | Unauthorized |
| 429 | Rate limit exceeded |
| 500 | Internal error |
