<?php

$ch = curl_init("https://api.myapi.rest/api/qrcode/generate");

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer <API_KEY>",
        "Content-Type: application/json"
    ],
    CURLOPT_POSTFIELDS => json_encode([
        "data" => "https://marquis.it.com",
        "output_format" => "PNG",
        "pixels_per_module" => 20
    ])
]);

echo curl_exec($ch);
curl_close($ch);
