const payload = {
  data: "https://marquis.it.com",
  output_format: "PNG",
  pixels_per_module: 20
};

fetch("https://api.myapi.rest/api/qrcode/generate", {
  method: "POST",
  headers: {
    "Authorization": "Bearer <API_KEY>",
    "Content-Type": "application/json"
  },
  body: JSON.stringify(payload)
})
  .then(r => r.text())
  .then(console.log);
