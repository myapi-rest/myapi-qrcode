import requests

res = requests.post(
    "https://api.myapi.rest/api/qrcode/generate",
    headers={"Authorization": "Bearer <API_KEY>"},
    json={
        "data": "https://marquis.it.com",
        "output_format": "PNG",
        "pixels_per_module": 20
    }
)

print(res.text)
