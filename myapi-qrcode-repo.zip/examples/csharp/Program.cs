using System;
using System.Net.Http;
using System.Net.Http.Json;

class Program
{
    static async System.Threading.Tasks.Task Main()
    {
        using var client = new HttpClient();
        client.DefaultRequestHeaders.Add("Authorization", "Bearer <API_KEY>");

        var res = await client.PostAsJsonAsync(
            "https://api.myapi.rest/api/qrcode/generate",
            new {
                data = "https://marquis.it.com",
                output_format = "PNG",
                pixels_per_module = 20
            });

        Console.WriteLine(await res.Content.ReadAsStringAsync());
    }
}
