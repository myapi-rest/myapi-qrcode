# myapi.rest — QR Code API

Generate customizable QR Codes via a simple, fast API.

See `/docs` for full documentation.
